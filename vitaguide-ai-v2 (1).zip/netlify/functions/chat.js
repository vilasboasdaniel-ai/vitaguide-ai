export default async (req) => {
  try {
    const { message } = await req.json();

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: "És um assistente de bem-estar. Respondes de forma simples e prática, sem diagnósticos médicos."
          },
          {
            role: "user",
            content: message
          }
        ]
      })
    });

    const data = await response.json();

    return new Response(JSON.stringify({
      reply: data.choices?.[0]?.message?.content || "Sem resposta"
    }), {
      headers: { "Content-Type": "application/json" }
    });

  } catch (e) {
    return new Response(JSON.stringify({ reply: "Erro na IA" }), {
      headers: { "Content-Type": "application/json" }
    });
  }
};
