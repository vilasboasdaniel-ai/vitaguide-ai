import { useState } from "react";

export default function App() {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Olá, sou o VitaGuide AI. Como te sentes hoje?" }
  ]);

  const [input, setInput] = useState("");

  async function sendMessage() {
    if (!input.trim()) return;

    setMessages(prev => [...prev, { role: "user", content: input }]);

    const res = await fetch("/.netlify/functions/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: input })
    });

    const data = await res.json();

    setMessages(prev => [
      ...prev,
      { role: "assistant", content: data.reply }
    ]);

    setInput("");
  }

  return (
    <div style={{ maxWidth: 700, margin: "0 auto", fontFamily: "Arial" }}>
      <h1>VitaGuide AI</h1>

      <div style={{ border: "1px solid #ccc", padding: 10, height: 400, overflowY: "auto" }}>
        {messages.map((m, i) => (
          <p key={i}>
            <b>{m.role === "user" ? "Tu" : "AI"}:</b> {m.content}
          </p>
        ))}
      </div>

      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        style={{ width: "80%", padding: 10 }}
      />
      <button onClick={sendMessage} style={{ padding: 10 }}>Enviar</button>
    </div>
  );
}
